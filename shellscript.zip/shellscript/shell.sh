cd /home/linux-18/Desktop/
mkdir ranga
cd ranga
touch file1.txt
echo "jenkins" > file2.txt
